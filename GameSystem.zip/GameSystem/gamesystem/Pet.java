package gamesystem;

public class Pet {
    public int healCharges;
    public Player owner;

    public Pet(Player owner) {
        // TO DO: Assign the owner parameter.
        // TO DO: Set healCharges to 3.
        this.owner = owner;
        this.healCharges = 3;
    }

    public void healOwner() {
        // TO DO: A pet can only heal if its owner is alive AND the pet has more than 0 healCharges.
        // TO DO: If valid, add 30 to the owner's HealthBar's currentHP.
        // TO DO: Subtract 1 from healCharges.
        // TO DO: currentHP cannot exceed 100. If it goes over, cap it exactly at 100.
        if(owner.isAlive && this.healCharges > 0){
            owner.hpBar.currentHP += 30;
            this.healCharges--;
        }
        if(this.owner.hpBar.currentHP > 100)
                owner.hpBar.currentHP = 100;

    }
}