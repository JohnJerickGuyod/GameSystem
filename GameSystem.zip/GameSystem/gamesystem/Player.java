package gamesystem;

public class Player {
    // Static Variables
    public static int activePlayers = 0;
    
    // Instance Variables
    public String username;
    public boolean isAlive;
    
    // Object Reference Variables
    public HealthBar hpBar;
    public Weapon equippedWeapon;
    public Pet activePet;

    public Player(String username) {
        // TO DO: Assign the username using 'this'.
        // TO DO: Set isAlive to true.
        // TO DO: Increment the activePlayers counter.
        // TO DO: Instantiate hpBar, equippedWeapon, and activePet.
        this.username = username;
        this.isAlive = true;
        Player.activePlayers++;
        this.hpBar = new HealthBar(this);
        this.equippedWeapon = new Weapon(this);
        this.activePet = new Pet(this);
    }

    public void die() {
        // TO DO: If the player is currently alive, set isAlive to false and decrement activePlayers.
        // TO DO: Ensure activePlayers is NOT decremented multiple times if die() is called again.
        if(isAlive){
            this.isAlive = false;
            Player.activePlayers--;
        }
        
    }

    // --- COMBAT SIMULATION METHODS ---

    public void executeAttack(Player target) {
        // TO DO: Delegate this action by calling the attack() method on this player's equippedWeapon.
        // Pass the target to the weapon.
        this.equippedWeapon.attack(target);
    }

    public void useHeal() {
        // TO DO: Delegate this action by calling the healOwner() method on this player's activePet.
        this.activePet.healOwner();
    }

    public void clash(Player opponent) {
        // TO DO: 1. This player calls executeAttack() on the opponent.
        // TO DO: 2. Check if the opponent is still alive.
        // TO DO: 3. If the opponent survived, they must call executeAttack() back on this player.
        this.executeAttack(opponent);
        if(opponent.isAlive){
            opponent.executeAttack(this);
        }
    }
}