package gamesystem;

public class HealthBar {
    public int currentHP;
    public Player owner;

    public HealthBar(Player owner) {
        // TO DO: Assign the owner parameter to the instance variable using 'this'.
        // TO DO: Set currentHP to 100.
         this.owner = owner;
        this.currentHP = 100;
    }

    public void takeDamage(int damage) {
        // TO DO: Subtract damage from currentHP.
        // TO DO: If currentHP drops to 0 or below, set it exactly to 0.
        // TO DO: If currentHP hits 0, you must call the die() method on the owner object.
        this.currentHP -= damage;
        if(currentHP <= 0){
            currentHP = 0;
            owner.die();
        }
    }
}