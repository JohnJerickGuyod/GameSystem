package gamesystem;

public class Weapon {
    public int attackPower;
    public Player owner;

    public Weapon(Player owner) {
        // TO DO: Assign the owner parameter.
        // TO DO: Set attackPower to 20.
         this.owner = owner;
        this.attackPower = 20;
    }

    public void attack(Player target) {
        // TO DO: A weapon can only deal damage if ITS owner is alive, AND the target is alive.
        // TO DO: If valid, access the target's hpBar and call takeDamage(), passing this weapon's attackPower.
        
        if(owner.isAlive && target.isAlive)
            target.hpBar.takeDamage(attackPower);
    }
}