
package Checker;

import midtermgrader.MidtermGrader;
import gamesystem.*;
public class Checker {

    public static void main(String[] args) {
        MidtermGrader.runTests();
    }
}
